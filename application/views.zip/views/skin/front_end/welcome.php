<?php 
	$this->load->view('skin/front_end/header_front_end');
	$this->load->view('content_front_end/home_page');
	$this->load->view('skin/front_end/footer_front_end');
?>