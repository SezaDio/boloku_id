<?php 
	$this->load->view('skin/admin/header_admin');
	$this->load->view('skin/admin/nav_kiri');
	$this->load->view('content_admin/dashboard');
	$this->load->view('skin/admin/footer_admin');
?>