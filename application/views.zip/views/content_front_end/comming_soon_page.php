      <section class="my-breadcrumb">
         <div class="container page-banner">
            <div class="row">
               <div class="col-sm-12 col-md-12 col-xs-12">
                  <h1>Comming Soon</h1>
               </div>
            </div>
         </div>
      </section>

      <!--Main Content-->
      <section class="main-content">
         <div class="container">
            <div class="row">
               <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="section ">
                     <div class="row">
                        <div class="posts-masonry">

                           <article class="col-md-4 col-sm-4 col-xs-12">
                              <div class="grid-1 gride-style-2">
                                 <div class="picture">
                                    <div class="category-image">
                                       <a href="standard-post.html">
                                       <img alt="" class="img-responsive" src="<?php echo base_url('asset/img/slide-11.jpg'); ?>">
                                       </a>
                                       <div class="catname">
                                          <a class="btn btn-gray" href="#">
                                             <div>Food and Health</div>
                                          </a>
                                       </div>
                                       <div class="hover-show-div">
                                          <a href="" class="post-type">
                                          <i class="ti-music-alt"></i>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="detail">
                                    <div class="caption">
                                       <h5>
                                          <a href="standard-post.html">Burger King brings romance to Valentine's Day with two-holed soda cup</a>
                                       </h5>
                                    </div>
                                    <ul class="post-tools">
                                       <li> by <a href=""> <strong> Arsoo</strong> </a></li>
                                       <li>  12 Hours Ago </li>
                                       <li><a href=""> <i class="ti-thought"></i> 57</a> </li>
                                    </ul>
                                 </div>
                              </div>
                           </article>
                           <article class="col-md-4 col-sm-4 col-xs-12">
                              <div class="grid-1 gride-style-2">
                                 <div class="picture">
                                    <div class="category-image">
                                       <a href="standard-post.html">
                                       <img alt="" class="img-responsive" src="<?php echo base_url('asset/img/slide-11.jpg'); ?>">
                                       </a>
                                       <div class="catname">
                                          <a class="btn btn-gray" href="#">
                                             <div>Food and Health</div>
                                          </a>
                                       </div>
                                       <div class="hover-show-div">
                                          <a href="" class="post-type">
                                          <i class="ti-music-alt"></i>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="detail">
                                    <div class="caption">
                                       <h5>
                                          <a href="standard-post.html">Burger King brings romance to Valentine's Day with two-holed soda cup</a>
                                       </h5>
                                    </div>
                                    <ul class="post-tools">
                                       <li> by <a href=""> <strong> Arsoo</strong> </a></li>
                                       <li>  12 Hours Ago </li>
                                       <li><a href=""> <i class="ti-thought"></i> 57</a> </li>
                                    </ul>
                                 </div>
                              </div>
                           </article>
                           <article class="col-md-4 col-sm-4 col-xs-12">
                              <div class="grid-1 gride-style-2">
                                 <div class="picture">
                                    <div class="category-image">
                                       <a href="standard-post.html">
                                       <img alt="" class="img-responsive" src="<?php echo base_url('asset/img/slide-11.jpg'); ?>">
                                       </a>
                                       <div class="catname">
                                          <a class="btn btn-gray" href="#">
                                             <div>Food and Health</div>
                                          </a>
                                       </div>
                                       <div class="hover-show-div">
                                          <a href="" class="post-type">
                                          <i class="ti-music-alt"></i>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="detail">
                                    <div class="caption">
                                       <h5>
                                          <a href="standard-post.html">Burger King brings romance to Valentine's Day with two-holed soda cup</a>
                                       </h5>
                                    </div>
                                    <ul class="post-tools">
                                       <li> by <a href=""> <strong> Arsoo</strong> </a></li>
                                       <li>  12 Hours Ago </li>
                                       <li><a href=""> <i class="ti-thought"></i> 57</a> </li>
                                    </ul>
                                 </div>
                              </div>
                           </article>
                           <article class="col-md-4 col-sm-4 col-xs-12">
                              <div class="grid-1 gride-style-2">
                                 <div class="picture">
                                    <div class="category-image">
                                       <a href="standard-post.html">
                                       <img alt="" class="img-responsive" src="<?php echo base_url('asset/img/slide-11.jpg'); ?>">
                                       </a>
                                       <div class="catname">
                                          <a class="btn btn-gray" href="#">
                                             <div>Food and Health</div>
                                          </a>
                                       </div>
                                       <div class="hover-show-div">
                                          <a href="" class="post-type">
                                          <i class="ti-music-alt"></i>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="detail">
                                    <div class="caption">
                                       <h5>
                                          <a href="standard-post.html">Burger King brings romance to Valentine's Day with two-holed soda cup</a>
                                       </h5>
                                    </div>
                                    <ul class="post-tools">
                                       <li> by <a href=""> <strong> Arsoo</strong> </a></li>
                                       <li>  12 Hours Ago </li>
                                       <li><a href=""> <i class="ti-thought"></i> 57</a> </li>
                                    </ul>
                                 </div>
                              </div>
                           </article>
                           <article class="col-md-4 col-sm-4 col-xs-12">
                              <div class="grid-1 gride-style-2">
                                 <div class="picture">
                                    <div class="category-image">
                                       <a href="standard-post.html">
                                       <img alt="" class="img-responsive" src="<?php echo base_url('asset/img/slide-11.jpg'); ?>">
                                       </a>
                                       <div class="catname">
                                          <a class="btn btn-gray" href="#">
                                             <div>Food and Health</div>
                                          </a>
                                       </div>
                                       <div class="hover-show-div">
                                          <a href="" class="post-type">
                                          <i class="ti-music-alt"></i>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="detail">
                                    <div class="caption">
                                       <h5>
                                          <a href="standard-post.html">Burger King brings romance to Valentine's Day with two-holed soda cup</a>
                                       </h5>
                                    </div>
                                    <ul class="post-tools">
                                       <li> by <a href=""> <strong> Arsoo</strong> </a></li>
                                       <li>  12 Hours Ago </li>
                                       <li><a href=""> <i class="ti-thought"></i> 57</a> </li>
                                    </ul>
                                 </div>
                              </div>
                           </article>
                           <article class="col-md-4 col-sm-4 col-xs-12">
                              <div class="grid-1 gride-style-2">
                                 <div class="picture">
                                    <div class="category-image">
                                       <a href="standard-post.html">
                                       <img alt="" class="img-responsive" src="<?php echo base_url('asset/img/slide-11.jpg'); ?>">
                                       </a>
                                       <div class="catname">
                                          <a class="btn btn-gray" href="#">
                                             <div>Food and Health</div>
                                          </a>
                                       </div>
                                       <div class="hover-show-div">
                                          <a href="" class="post-type">
                                          <i class="ti-music-alt"></i>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="detail">
                                    <div class="caption">
                                       <h5>
                                          <a href="standard-post.html">Burger King brings romance to Valentine's Day with two-holed soda cup</a>
                                       </h5>
                                    </div>
                                    <ul class="post-tools">
                                       <li> by <a href=""> <strong> Arsoo</strong> </a></li>
                                       <li>  12 Hours Ago </li>
                                       <li><a href=""> <i class="ti-thought"></i> 57</a> </li>
                                    </ul>
                                 </div>
                              </div>
                           </article>

                        </div>
                     </div>
                  </div>
               </div>

               <div class="pagination-holder">
                  <nav>
                     <ul class="pagination">
                        <li>
                           <a aria-label="Previous" href=" #"><span aria-hidden="true"><i class="fa fa-angle-left"></i></span></a>
                        </li>
                        <li class="active">
                           <a href=" #">1 <span class="sr-only">(current)</span></a>
                        </li>
                        <li>
                           <a href=" #">2</a>
                        </li>
                        <li>
                           <a href=" #">3</a>
                        </li>
                        <li>
                           <a aria-label="Next" href=" #"><span aria-hidden="true"><i class="fa fa-angle-right"></i></span></a>
                        </li>
                     </ul>
                  </nav>
               </div>
            </div>
         </div>
      </section>