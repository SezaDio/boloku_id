<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Payment extends CI_Controller {

		public function _construct()
		{
			parent::_construct();
			$this->load->helper('url');
			$this->load->helper('form');
			$this->load->library('input');
			$this->load->library('form_validation');
			$this->load->library('session');

		}

		public function notify()
		{
			$transidmerchant = $this->input->post('TRANSIDMERCHANT');
			$data_notify = array(
						   'statustype'=>$this->input->post('STATUSTYPE'),
						   'response_code'=>$this->input->post('RESPONSECODE'),
						   'approvalcode'=>$this->input->post('APPROVALCODE'),
						   'payment_channel'=>$this->input->post('PAYMENTCHANNEL'),
						   'payment_channel'=>$this->input->post('PAYMENTCHANNEL'),
						   'paymentcode'=>$this->input->post('PAYMENTCODE'),
						   'session_id'=>$this->input->post('SESSIONID'),
						   'bank_issuer'=>$this->input->post('BANK'),
						   'creditcard'=>$this->input->post('MCN'),
						   'verifyid'=>$this->input->post('VERIFYID'),
						   'verifyscore'=>$this->input->post('VERIFYSCORE'),
						   'verifystatus'=>$this->input->post('VERIFYSTATUS')
						   )
			$this->db->update('doku', $data_notify, array('transidmerchant'=>$transidmerchant));

			echo "CONTINUE";

		}
	}
